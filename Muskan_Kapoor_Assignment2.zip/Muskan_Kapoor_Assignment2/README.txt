Muskan Kapoor

i. All parts of the  assignment are completed
ii. I have encountered no bugs.
iii. Instructions to complete are as normal:     
To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

part 2a: ./query_tree rebase210.txt

To run with a given file that is redirected to standard input:

./query_tree rebase210.txt < input_part2a.txt

 
part 2b: ./test_tree rebase210.txt sequences.txt

part 2c: ./test_tree_mod rebase210.txt sequences.txt

iv. I have used the same exact Makefile. 


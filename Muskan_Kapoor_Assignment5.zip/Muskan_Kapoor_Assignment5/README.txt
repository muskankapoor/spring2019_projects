Muskan Kapoor

i. All parts of the  assignment are completed. Extra credit is also completed.
ii. I have encountered no bugs.
iii. Instructions to complete are as normal:     
To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

./optimal_multiplications dimensions_file.txt




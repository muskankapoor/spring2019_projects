Muskan Kapoor

i. All parts of the  assignment are completed
ii. I have encountered no bugs.
iii. INstructions to complete are as normal:     
To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

./test_points2

To run with a given file that is redirected to standard input:

./test_points2 < test_input_file.txt


I have used the  exact Makefile and test_points2.cc


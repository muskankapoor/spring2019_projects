Muskan Kapoor

i. All parts of the  assignment are completed
ii. I have encountered no bugs.
iii. Instructions to complete are as normal:     
To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

part 1 and part 2: 
./create_and_test_hash <words file name> <query words file name> <flag>
Example:
./create_and_test_hash words.txt query_words.txt quadratic

part 2:
the exact R I am using is 191

part c: spell_check <document file> <dictionary file>
Example:
./spell_check document1.txt wordsEn.txt


 I have used the same exact Makefile. 


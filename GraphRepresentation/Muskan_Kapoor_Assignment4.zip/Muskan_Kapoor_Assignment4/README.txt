Muskan Kapoor

i. All parts of the  assignment are completed
ii. I have encountered no bugs.There are some warnings for the second part.
iii. Instructions to complete are as normal:     
To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

part 1 
/CreateGraphAndTest Graph1.txt AdjacencyQueries1.txt

part 2:
./FindPaths Graph2.txt 1

part c: 
./TestRandomGraph <maximum_number_of_nodes>
./TestRandoGraph 100



